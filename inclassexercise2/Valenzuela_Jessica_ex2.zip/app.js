const bands = require('./bands')

async function main() {
    const createdBand = await bands.addBand("Pink Floyd", ["Roger Waters","David Gilmour", "Richard Wright", "Nick Mason"], 1965, ["Psychedelic rock", "Classic Rock", "Rock"],"Columbia Records");
    console.log(createdBand);
    const getAllBands = await bands.getAllBands();
    console.log(getAllBands);
    const removeBand = await bands.removeBand("9714a17c-f228-49e9-a772-9086f5ff8bfb");
    console.log(removeBand)
    try {
        return await bands.getBand("9714a17c-f228-49e9-a772-9086f5ff8bfb");
    } catch (error) {
      console.error(error);
   }
    const updatedBand = await bands.updateBand("Pink Floyd", ["Roger Waters","David Gilmour", "Richard Wright", "Nick Mason", "Syd Barrett"], 1965, ["Psychedelic rock", "Classic Rock", "Rock", "Progressive Rock"],"EMI"); 
    console.log(updatedBand);



}   

main();